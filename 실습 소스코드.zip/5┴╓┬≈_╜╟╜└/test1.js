document.write("<H2>test1.js 파일 출력 결과</H2>");
document.write("외부 스크립트 연동 성공<BR>");